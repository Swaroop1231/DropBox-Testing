//
//  DBObject.m
//  DropBox_Sample
//
//  Created by basanth alluri on 12/25/13.
//  Copyright (c) 2013 StellentSoft. All rights reserved.
//

#import "DBObject.h"

@implementation DBObject
@synthesize  taskNameStr;
@synthesize taskDescStr;
@synthesize taskDateStr;
@synthesize taskiD;

@end
