//
//  DBViewController.h
//  DropBox_Sample
//
//  Created by basanth alluri on 12/24/13.
//  Copyright (c) 2013 StellentSoft. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Dropbox/Dropbox.h>

@class DBObject;

@interface DBViewController : UIViewController<UITextFieldDelegate>


@property (nonatomic, readonly) DBAccountManager *accountManager;
@property (nonatomic, readonly) DBAccount *account;
@property (nonatomic, strong) DBDatastore *store;
@property(nonatomic,strong) NSMutableArray *tasks;
@property(nonatomic,strong) NSMutableArray *objectsArray;

@property(nonatomic,strong) IBOutlet UITextField *taskNameTextField;
@property(nonatomic,strong) IBOutlet UITextField *taskCompleteTextField;



- (IBAction)didPressLink;
- (IBAction)didPressUnlink;
-(void)getDataFromDropBox;
-(void)deleteRecordsFromDropBox;
-(void)updateRecordsFromDropBox;

- (IBAction)submitButtonAction;
- (IBAction)detailViewButtonAction;



@end
