//
//  UIImage+SmallImage.h
//  DropBox_Sample
//
//  Created by basanth alluri on 12/26/13.
//  Copyright (c) 2013 StellentSoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (SmallImage)

+(UIImage*)imageWithImage:(UIImage*)image andWidth:(CGFloat)width andHeight:(CGFloat)height;

@end
