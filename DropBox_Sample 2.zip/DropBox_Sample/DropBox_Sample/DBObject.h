//
//  DBObject.h
//  DropBox_Sample
//
//  Created by basanth alluri on 12/25/13.
//  Copyright (c) 2013 StellentSoft. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DBObject : NSObject
@property(nonatomic,strong) NSString *taskNameStr;
@property(nonatomic,strong) NSString *taskDescStr;
@property(nonatomic,strong) NSString *taskDateStr;
@property(nonatomic,strong) NSString *taskiD;




@end
