//
//  AppDelegate.h
//  DropBox_Sample
//
//  Created by basanth alluri on 12/24/13.
//  Copyright (c) 2013 StellentSoft. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "DBViewController.h"
#import <Dropbox/Dropbox.h>


@interface AppDelegate : UIResponder <UIApplicationDelegate,UINavigationControllerDelegate>

@property (strong, nonatomic) UIWindow *window;
@property(nonatomic,strong) DBViewController *dbViewController;
@property(nonatomic,strong) UINavigationController *navigationController;


@end
