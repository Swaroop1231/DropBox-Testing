//
//  UIImage+SmallImage.m
//  DropBox_Sample
//
//  Created by basanth alluri on 12/26/13.
//  Copyright (c) 2013 StellentSoft. All rights reserved.
//

#import "UIImage+SmallImage.h"

@implementation UIImage (SmallImage)


+(UIImage*)imageWithImage:(UIImage*)image andWidth:(CGFloat)width andHeight:(CGFloat)height
{
    UIGraphicsBeginImageContext( CGSizeMake(width, height));
    [image drawInRect:CGRectMake(0,0,width,height)];
    UIImage* newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return newImage;
}

@end
