//
//  DBDetailViewController.m
//  DropBox_Sample
//
//  Created by basanth alluri on 12/25/13.
//  Copyright (c) 2013 StellentSoft. All rights reserved.
//

#import "DBDetailViewController.h"
#import "DBObject.h"

@interface DBDetailViewController ()

@end

@implementation DBDetailViewController
@synthesize detailTableView;
@synthesize accountManager;
@synthesize account;
@synthesize store;
@synthesize tasks;
@synthesize objectsArray;
@synthesize indexPathOfCell;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    tasks=[[NSMutableArray alloc]init];
    objectsArray=[[NSMutableArray alloc]init];
    [self getDataFromDropBox];
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    __weak DBDetailViewController *slf = self;
    
    [self.accountManager addObserver:self block:^(DBAccount *account) {
        // [slf setupTasks];
    }];

}
#pragma mark -get Data From DropBox

-(void)getDataFromDropBox
{
    [objectsArray removeAllObjects];
    tasks = [NSMutableArray arrayWithArray:[[self.store getTable:@"tasks"] query:nil error:nil]];
    NSLog(@"Tasks array is %@",tasks.description);
    
    for (int k=0; k<[tasks count]; k++)
    {
        DBObject *dbObj=[[DBObject alloc]init];
        DBRecord *recordObj=[tasks objectAtIndex:k];
        dbObj.taskNameStr=recordObj[@"taskname"];
        NSLog(@"Task Name is %@",dbObj.taskNameStr);
        NSLog(@"image is %@",recordObj[@"savedImage"]);

        
        dbObj.taskDescStr=recordObj[@"completed"];
        dbObj.taskDateStr=recordObj[@"created"];
#pragma mark
#pragma mark -get record id of DropBox
        
        dbObj.taskiD=recordObj.recordId;
        NSLog(@"Task Id is %@",dbObj.taskiD);
        
        [objectsArray addObject:dbObj];
        
    }
    
    [self.detailTableView reloadData];
    NSLog(@"onjects array is %@",objectsArray.description);
}


#pragma mark -Delete Data From DropBox

-(void)deleteRecordsFromDropBox
{
    
    DBRecord *delrecord=[tasks objectAtIndex:indexPathOfCell];

    NSLog(@"delete record %@ ",delrecord);
    [delrecord deleteRecord];
    [self.store sync:nil];
    if ([delrecord isDeleted])
    {
        NSLog(@"record is deleed ");
        
       // [detailTableView reloadData];
        [self getDataFromDropBox];
    }
    else{
                NSLog(@"record noooooot deleed ");
    }
    
}

#pragma mark -Update Data From DropBox

-(void)updateRecordsFromDropBox
{
    DBRecord *firstResult = [tasks objectAtIndex:indexPathOfCell];
    [firstResult setObject:@"Swaroop" forKey:@"taskname"];
    [self.store sync:nil];
    
    [self getDataFromDropBox ];
    
}


#pragma mark - private methods

- (DBAccount *)account {
    return [DBAccountManager sharedManager].linkedAccount;
}

- (DBAccountManager *)accountManager {
    return [DBAccountManager sharedManager];
}

- (DBDatastore *)store
{
    if (!store)
    {
        
        store = [DBDatastore openDefaultStoreForAccount:self.account error:nil];
    }
    return store;
}




#pragma TableView Delegate Methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
#warning Potentially incomplete method implementation.
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
#warning Incomplete method implementation.
    // Return the number of rows in the section.
    return [objectsArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    DBObject *myObj=[objectsArray objectAtIndex:indexPath.row];
    cell.textLabel.text=myObj.taskNameStr;
    cell.detailTextLabel.text=myObj.taskDescStr;
    
    // Configure the cell...
    
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    indexPathOfCell=indexPath.row;
    UIAlertView *alertView=[[UIAlertView alloc]initWithTitle:@"DropBox" message:@"Do you want to edit this field?" delegate:self cancelButtonTitle:nil otherButtonTitles:@"Delete",@"Update",nil];
    alertView.delegate=self;
    [alertView show];
    
}
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex==0)
    {
        NSLog(@"Delete Selected");
        [self deleteRecordsFromDropBox];
    }
    else
    {
        NSLog(@"Update Selected");

        [self  updateRecordsFromDropBox];
    }

    
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
