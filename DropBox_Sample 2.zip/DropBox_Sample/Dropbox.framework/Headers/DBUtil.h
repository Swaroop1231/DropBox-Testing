/* Copyright (c) 2012 Dropbox, Inc. All rights reserved. */

/** A generic block type used for observing changes throughout the Sync API */
typedef void (^DBObserver)();
